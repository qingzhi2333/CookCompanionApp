package com.leaf.cookcompanion;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.leaf.cookcompanion.bean.Student;
import com.leaf.cookcompanion.util.StudentDbHelper;

import java.util.LinkedList;

/**
 * Modify personal information Activity class
 * @author : autumn_leaf
 */
public class ModifyInfoActivity extends AppCompatActivity {

    EditText etStuName,etMajor,etPhone,etQq,etAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modify_info);
        Button btnBack = findViewById(R.id.btn_back);
        //Back button click event
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //Using bundle to transfer account
        final TextView tvStuNumber = findViewById(R.id.tv_stu_number);
        tvStuNumber.setText(this.getIntent().getStringExtra("stu_number2"));
        etStuName = findViewById(R.id.et_stu_name);
        etMajor = findViewById(R.id.et_stu_major);
        etPhone = findViewById(R.id.et_stu_phone);
        etQq = findViewById(R.id.et_stu_qq);
        etAddress = findViewById(R.id.et_stu_address);
        StudentDbHelper dbHelper = new StudentDbHelper(getApplicationContext(),StudentDbHelper.DB_NAME,null,1);
        LinkedList<Student> students = dbHelper.readStudents(tvStuNumber.getText().toString());
        //If the user information found is not empty
        if(students != null) {
            for(Student student : students) {
                etStuName.setText(student.getStuName());
                etMajor.setText(student.getStuMajor());
                etPhone.setText(student.getStuPhone());
                etQq.setText(student.getStuQq());
                etAddress.setText(student.getStuAddress());
            }
        }
        Button btnSaveInfo = findViewById(R.id.btn_save_info);
        btnSaveInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //First determine whether the input is empty
                if(CheckInput()) {
                    StudentDbHelper dbHelper = new StudentDbHelper(getApplicationContext(),StudentDbHelper.DB_NAME,null,1);
                    Student student = new Student();
                    student.setStuNumber(tvStuNumber.getText().toString());
                    student.setStuName(etStuName.getText().toString());
                    student.setStuMajor(etMajor.getText().toString());
                    student.setStuPhone(etPhone.getText().toString());
                    student.setStuQq(etQq.getText().toString());
                    student.setStuAddress(etAddress.getText().toString());
                    dbHelper.saveStudent(student);
                    Toast.makeText(getApplicationContext(),"User information saved successfully!",Toast.LENGTH_SHORT).show();
                    //Destroy the current interface
                    finish();
                }
            }
        });
    }

    //Check if input is empty
    public boolean CheckInput() {
        String StuName = etStuName.getText().toString();
        String StuMajor = etMajor.getText().toString();
        String StuPhone = etPhone.getText().toString();
        String StuQq = etQq.getText().toString();
        String StuAddress = etAddress.getText().toString();
        if(StuName.trim().equals("")) {
            Toast.makeText(this,"Name cannot be empty!",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(StuMajor.trim().equals("")) {
            Toast.makeText(this,"Allergens cannot be empty!",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(StuPhone.trim().equals("")) {
            Toast.makeText(this,"Contact information cannot be empty!",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(StuQq.trim().equals("")) {
            Toast.makeText(this,"Mail cannot be empty!",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(StuAddress.trim().equals("")) {
            Toast.makeText(this,"City cannot be empty!",Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
