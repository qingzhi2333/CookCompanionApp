package com.leaf.cookcompanion.util;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.leaf.cookcompanion.bean.User;

import java.util.LinkedList;

/**
 * User database connection class
 * @author : autumn_leaf
 */
public class UserDbHelper extends SQLiteOpenHelper {

    //Define the database table name
    public static final String DB_NAME = "tb_user";
    /** Create a user information table **/
    private static final String CREATE_USER_DB = "create table tb_user (" +
            "id integer primary key autoincrement," +
            "uuid text," +
            "username text," +
            "password text )";


    public UserDbHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_DB);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    /**
     * Add user information when registering
     * @param user user
     */
    public void addUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("uuid",user.getUuid());
        values.put("username",user.getUsername());
        values.put("password",user.getPassword());
        db.insert(DB_NAME,null,values);
        values.clear();
    }

    /**
     * Query user information when logging in
     * @return users Query users
     */
    public LinkedList<User> readUsers() {
        LinkedList<User> users = new LinkedList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from tb_user",null);
        if(cursor.moveToFirst()) {
            do{
                String uuid = cursor.getString(cursor.getColumnIndex("uuid"));
                String username = cursor.getString(cursor.getColumnIndex("username"));
                String password = cursor.getString(cursor.getColumnIndex("password"));
                User user = new User();
                user.setUuid(uuid);
                user.setUsername(username);
                user.setPassword(password);
                users.add(user);
            }while (cursor.moveToNext());
        }
        cursor.close();
        return users;
    }

    /**
     * Change password function
     * @param username username
     * @param password password
     * @return Is it modified?
     */
    public boolean updateUser(String username,String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "update tb_user set password=? where username=?";
        String[] obj = new String[]{password,username};
        db.execSQL(sql,obj);
        return true;
    }

}
