package com.leaf.cookcompanion;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.leaf.cookcompanion.bean.Student;
import com.leaf.cookcompanion.util.StudentDbHelper;

import java.util.LinkedList;

/**
 * My personal information activities
 * @author : autumn_leaf
 */
public class MyInfoActivity extends AppCompatActivity {

    TextView tvStuName,tvStuMajor,tvStuPhone,tvStuQq,tvStuAddress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_info);
        Button btnBack = findViewById(R.id.btn_back);
        //Return click event and destroy the current interface
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        //Get the user account from the bundle
        final TextView tvUserNumber = findViewById(R.id.tv_stu_number);
        tvUserNumber.setText(this.getIntent().getStringExtra("stu_number1"));
        tvStuName = findViewById(R.id.tv_stu_name);
        tvStuMajor = findViewById(R.id.tv_stu_major);
        tvStuPhone = findViewById(R.id.tv_stu_phone);
        tvStuQq = findViewById(R.id.tv_stu_qq);
        tvStuAddress = findViewById(R.id.tv_stu_address);
        StudentDbHelper dbHelper = new StudentDbHelper(getApplicationContext(),StudentDbHelper.DB_NAME,null,1);
        LinkedList<Student> students = dbHelper.readStudents(tvUserNumber.getText().toString());
        if(students != null) {
            for(Student student : students) {
                tvStuName.setText(student.getStuName());
                tvStuMajor.setText(student.getStuMajor());
                tvStuPhone.setText(student.getStuPhone());
                tvStuQq.setText(student.getStuQq());
                tvStuAddress.setText(student.getStuAddress());
            }
        }else {
            tvStuName.setText("Not filled in yet");
            tvStuMajor.setText("Not filled in yet");
            tvStuPhone.setText("Not filled in yet");
            tvStuQq.setText("Not filled in yet");
            tvStuAddress.setText("Not filled in yet");
        }
        Button btnModifyInfo = findViewById(R.id.btn_modify_info);
        //Jump to the modify user information interface
        btnModifyInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ModifyInfoActivity.class);
                Bundle bundle = new Bundle();
                bundle.putString("stu_number2",tvUserNumber.getText().toString());
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        //Refresh button click event
        TextView tvRefresh = findViewById(R.id.tv_refresh);
        tvRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StudentDbHelper dbHelper1 = new StudentDbHelper(getApplicationContext(),StudentDbHelper.DB_NAME,null,1);
                LinkedList<Student> students = dbHelper1.readStudents(tvUserNumber.getText().toString());
                if(students != null) {
                    for(Student student : students) {
                        tvStuName.setText(student.getStuName());
                        tvStuMajor.setText(student.getStuMajor());
                        tvStuPhone.setText(student.getStuPhone());
                        tvStuQq.setText(student.getStuQq());
                        tvStuAddress.setText(student.getStuAddress());
                    }
                }
            }
        });

    }
}
