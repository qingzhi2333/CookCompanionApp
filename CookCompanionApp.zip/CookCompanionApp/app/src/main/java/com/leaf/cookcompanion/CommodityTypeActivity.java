package com.leaf.cookcompanion;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;

import com.leaf.cookcompanion.adapter.AllCommodityAdapter;
import com.leaf.cookcompanion.bean.Commodity;
import com.leaf.cookcompanion.util.CommodityDbHelper;

import java.util.LinkedList;
import java.util.List;

/**
 * Activity categories for different types of product information
 * @author autumn_leaf
 */
public class CommodityTypeActivity extends AppCompatActivity {

    TextView tvCommodityType;
    ListView lvCommodityType;
    List<Commodity> commodities = new LinkedList<>();

    CommodityDbHelper dbHelper;
    AllCommodityAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_commodity_type);
        //Return Event
        TextView tvBack = findViewById(R.id.tv_back);
        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        tvCommodityType = findViewById(R.id.tv_type);
        lvCommodityType = findViewById(R.id.list_commodity);
        dbHelper = new CommodityDbHelper(getApplicationContext(),CommodityDbHelper.DB_NAME,null,1);
        adapter = new AllCommodityAdapter(getApplicationContext());
        //Display different interfaces according to different states
        int status = this.getIntent().getIntExtra("status",0);
        if(status == 1) {
            tvCommodityType.setText("Mexican Food");
        }else if(status == 2) {
            tvCommodityType.setText("Asian Food");
        }else if(status == 3) {
            tvCommodityType.setText("Fast Food");
        }else if(status == 4) {
            tvCommodityType.setText("Italian Food");
        }
        //Display different product information according to different categories
        commodities = dbHelper.readCommodityType(tvCommodityType.getText().toString());
        adapter.setData(commodities);
        lvCommodityType.setAdapter(adapter);
    }
}
