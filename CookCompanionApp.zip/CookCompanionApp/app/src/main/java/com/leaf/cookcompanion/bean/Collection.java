package com.leaf.cookcompanion.bean;


/**
 * My Collection Entity Class
 * @author autumn_leaf
 */
public class Collection {

    //account
    private String StuId;
    //images
    private byte[] picture;
    //title
    private String title;
    //Description
    private String description;
    //Allergens
    private float price;
    //Contact
    private String phone;

    public String getStuId() {
        return StuId;
    }

    public void setStuId(String stuId) {
        StuId = stuId;
    }

    public byte[] getPicture() {
        return picture;
    }

    public void setPicture(byte[] picture) {
        this.picture = picture;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
