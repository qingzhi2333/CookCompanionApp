package com.leaf.cookcompanion.bean;

/**
 * Comment entity class
 * @author autumn_leaf
 */
public class Review {

    private String stuId;//User Account
    private String currentTime;//Current time
    private String content;//Comment content
    private Integer position;//Food item number

    public String getStuId() {
        return stuId;
    }

    public void setStuId(String stuId) {
        this.stuId = stuId;
    }

    public String getCurrentTime() {
        return currentTime;
    }

    public void setCurrentTime(String currentTime) {
        this.currentTime = currentTime;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getPosition() {
        return position;
    }

    public void setPosition(Integer position) {
        this.position = position;
    }
}


